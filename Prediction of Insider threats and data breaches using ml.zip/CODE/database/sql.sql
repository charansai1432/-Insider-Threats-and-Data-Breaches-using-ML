/*
SQLyog Enterprise - MySQL GUI v6.56
MySQL - 5.5.5-10.1.13-MariaDB : Database - cyber_hacking
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

CREATE DATABASE /*!32312 IF NOT EXISTS*/`cyber_hacking` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `cyber_hacking`;

/*Table structure for table `cyber` */

DROP TABLE IF EXISTS `cyber`;

CREATE TABLE `cyber` (
  `Name` varchar(100) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `Password` varchar(100) NOT NULL,
  `Age` varchar(100) NOT NULL,
  `Address` varchar(100) NOT NULL,
  `Contact` int(10) NOT NULL,
  PRIMARY KEY (`Name`,`Email`,`Password`,`Age`,`Address`,`Contact`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `cyber` */

insert  into `cyber`(`Name`,`Email`,`Password`,`Age`,`Address`,`Contact`) values ('hello','hello@gmail.com','123','25','ramarao peta',2147483647);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
